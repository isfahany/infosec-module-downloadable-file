<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Registrasi</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container">
            <h1>Lovely Cat Picture!!!</h1>
            <form action="index.php" method="GET">
                 <div class="dropdown">
                    <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Cat Picture
                    <span class="caret"></span></button>
                    <ul class="dropdown-menu" name="catto">
                        <li value="1"><a href="index.php?catto=1&desc=catto/foreign.php">1</a></li>
                        <li value="2"><a href="index.php?catto=2&desc=catto/local.php">2</a></li>
                        <li value="3"><a href="index.php?catto=3&desc=catto/local.php">3</a></li>
                        <li value="4"><a href="index.php?catto=4&desc=catto/local.php">4</a></li>
                        <li value="5"><a href="index.php?catto=5&desc=catto/local.php">5</a></li>
                        <li value="6"><a href="index.php?catto=6&desc=catto/foreign.php">6</a></li>
                        <li value="7"><a href="index.php?catto=7&desc=catto/foreign.php">7</a></li>
                        <li value="8"><a href="index.php?catto=8&desc=catto/local.php">8</a></li>
                        <li value="9"><a href="index.php?catto=9&desc=catto/local.php">9</a></li>
                        <li value="10"><a href="index.php?catto=10&desc=catto/foreign.php">10</a></li>
                        <li value="11"><a href="index.php?catto=11&desc=catto/foreign.php">11</a></li>
                        <li value="12"><a href="index.php?catto=12&desc=catto/local.php">12</a></li>
                    </ul>
                </div>
            </form>
    <div>
    <hr/>
    <?php
    if(isset($_GET['catto'])){
        $filepath= './img/'.$_GET['catto'];
        echo '<img src='.$filepath.'>';
    }
    ?>
    <hr/>
    <?php
    if(isset($_GET['desc'])){
        include $_GET['desc'];
    }
    ?>
</body>
</html>
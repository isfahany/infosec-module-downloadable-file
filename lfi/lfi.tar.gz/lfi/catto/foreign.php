<?php

echo "this is foreign cat";
?>
